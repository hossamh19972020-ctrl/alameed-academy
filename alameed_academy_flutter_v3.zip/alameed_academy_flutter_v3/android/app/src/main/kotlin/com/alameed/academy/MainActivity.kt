package com.alameed.academy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
