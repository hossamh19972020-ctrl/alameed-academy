import 'package:flutter/material.dart';
import '../models/app_data.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التقارير')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('النسخة الحالية تعرض التقارير داخل التطبيق'),
              subtitle: Text('سيتم في المرحلة التالية إضافة PDF وExcel والمشاركة عبر واتساب.'),
            ),
          ),
          ...AppData.students.map((s) => Card(
                child: ExpansionTile(
                  leading: CircleAvatar(child: Text(s.name.characters.first)),
                  title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(s.group),
                  childrenPadding: const EdgeInsets.all(16),
                  children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                      _Metric(label: 'الحضور', value: s.isAbsent ? '0%' : '100%'),
                      _Metric(label: 'الدرجة', value: '${s.grade.toStringAsFixed(0)}%'),
                      _Metric(label: 'السداد', value: s.feesPaid ? 'تم' : 'متأخر'),
                    ]),
                    const SizedBox(height: 14),
                    const Text('رسالة من المعلم: استمر في الاجتهاد والمراجعة المنتظمة، مع خالص تمنياتي بالتوفيق.'),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(label)]);
  }
}
