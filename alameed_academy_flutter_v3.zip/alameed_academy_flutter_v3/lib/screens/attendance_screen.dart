import 'package:flutter/material.dart';
import '../models/app_data.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  String selectedGroup = AppData.groups.first;

  @override
  Widget build(BuildContext context) {
    final students = AppData.students.where((s) => s.group == selectedGroup).toList();
    final absentCount = students.where((s) => s.isAbsent).length;
    return Scaffold(
      appBar: AppBar(title: const Text('الحضور الذكي')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: DropdownButtonFormField<String>(
              value: selectedGroup,
              items: AppData.groups.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
              onChanged: (v) => setState(() => selectedGroup = v ?? selectedGroup),
              decoration: const InputDecoration(labelText: 'اختر المجموعة'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(child: Text('الإجمالي: ${students.length}')),
                Expanded(child: Text('الحاضر: ${students.length - absentCount}', style: const TextStyle(color: Colors.green))),
                Expanded(child: Text('الغائب: $absentCount', style: const TextStyle(color: Colors.red))),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('جميع الطلاب حاضرون افتراضيًا؛ حدّد الغائبين فقط.', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: students.length,
              itemBuilder: (_, i) {
                final s = students[i];
                return Card(
                  child: CheckboxListTile(
                    value: s.isAbsent,
                    onChanged: (v) => setState(() => s.isAbsent = v ?? false),
                    title: Text(s.name),
                    subtitle: Text(s.phone),
                    secondary: CircleAvatar(child: Text(s.name.characters.first)),
                    controlAffinity: ListTileControlAffinity.leading,
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton.icon(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الحضور بنجاح'))),
                icon: const Icon(Icons.save),
                label: const Text('حفظ الحضور'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
