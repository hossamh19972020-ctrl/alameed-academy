import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../models/student.dart';

class StudentsScreen extends StatefulWidget {
  const StudentsScreen({super.key});

  @override
  State<StudentsScreen> createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen> {
  String query = '';

  void addStudent() {
    final name = TextEditingController();
    final phone = TextEditingController();
    String group = AppData.groups.first;
    showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: const Text('إضافة طالب'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الطالب')),
              const SizedBox(height: 10),
              TextField(controller: phone, decoration: const InputDecoration(labelText: 'رقم ولي الأمر')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: group,
                items: AppData.groups.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                onChanged: (v) => setDialogState(() => group = v ?? group),
                decoration: const InputDecoration(labelText: 'المجموعة'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                if (name.text.trim().isEmpty) return;
                setState(() {
                  AppData.students.add(Student(
                    id: DateTime.now().millisecondsSinceEpoch,
                    name: name.text.trim(),
                    phone: phone.text.trim(),
                    group: group,
                  ));
                });
                Navigator.pop(dialogContext);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = AppData.students.where((s) => s.name.contains(query) || s.phone.contains(query)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الطلاب')),
      floatingActionButton: FloatingActionButton.extended(onPressed: addStudent, icon: const Icon(Icons.add), label: const Text('إضافة طالب')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (v) => setState(() => query = v.trim()),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث باسم الطالب أو رقم الهاتف'),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final s = list[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text(s.name.characters.first)),
                    title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${s.group}\n${s.phone}'),
                    isThreeLine: true,
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        if (value == 'delete') setState(() => AppData.students.remove(s));
                      },
                      itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف'))],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
