import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../models/payment_record.dart';
import '../models/student.dart';

class FeesScreen extends StatefulWidget {
  const FeesScreen({super.key});

  @override
  State<FeesScreen> createState() => _FeesScreenState();
}

class _FeesScreenState extends State<FeesScreen> {
  String _period = 'يوليو 2026';
  final _periods = const ['يوليو 2026', 'أغسطس 2026', 'سبتمبر 2026'];

  String _formatDateTime(DateTime value) {
    final d = value.day.toString().padLeft(2, '0');
    final m = value.month.toString().padLeft(2, '0');
    final h = value.hour.toString().padLeft(2, '0');
    final min = value.minute.toString().padLeft(2, '0');
    final sec = value.second.toString().padLeft(2, '0');
    return '$d/$m/${value.year} - $h:$min:$sec';
  }

  Future<void> _showAddPayment(Student student) async {
    final amountController = TextEditingController();
    final notesController = TextEditingController();
    String method = 'نقدي';

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('تسجيل دفعة: ${student.name}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: amountController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'المبلغ المدفوع',
                    prefixText: 'ج.م ',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: method,
                  decoration: const InputDecoration(
                    labelText: 'طريقة الدفع',
                    border: OutlineInputBorder(),
                  ),
                  items: const ['نقدي', 'تحويل بنكي', 'محفظة إلكترونية', 'إنستاباي']
                      .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                      .toList(),
                  onChanged: (value) => setDialogState(() => method = value ?? 'نقدي'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: notesController,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'ملاحظات (اختياري)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                const Row(
                  children: [
                    Icon(Icons.schedule, size: 18),
                    SizedBox(width: 6),
                    Expanded(child: Text('سيُسجَّل التاريخ والوقت تلقائيًا عند الحفظ.')),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                final amount = double.tryParse(amountController.text.trim());
                if (amount == null || amount <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('أدخل مبلغًا صحيحًا.')),
                  );
                  return;
                }
                AppData.addPayment(
                  studentId: student.id,
                  amount: amount,
                  period: _period,
                  method: method,
                  notes: notesController.text.trim(),
                );
                Navigator.pop(context, true);
              },
              child: const Text('حفظ الدفعة'),
            ),
          ],
        ),
      ),
    );

    if (saved == true && mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ الدفعة بالتاريخ والوقت تلقائيًا.')),
      );
    }
  }

  void _showHistory(Student student) {
    final records = AppData.paymentsForStudent(student.id);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .72,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Icon(Icons.receipt_long),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'سجل دفعات ${student.name}',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: records.isEmpty
                    ? const Center(child: Text('لا توجد دفعات مسجلة.'))
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: records.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, index) {
                          final p = records[index];
                          return Card(
                            child: ListTile(
                              leading: CircleAvatar(
                                child: Icon(p.isCancelled ? Icons.block : Icons.payments),
                              ),
                              title: Text('${p.amount.toStringAsFixed(0)} ج.م - ${p.period}'),
                              subtitle: Text(
                                '${_formatDateTime(p.paidAt)}\n${p.method} • ${p.receiptNumber}',
                              ),
                              isThreeLine: true,
                              trailing: p.isCancelled
                                  ? const Text('ملغاة', style: TextStyle(color: Colors.red))
                                  : const Icon(Icons.verified, color: Colors.green),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalRequired = AppData.students.fold<double>(0, (sum, s) => sum + s.monthlyFee);
    final totalPaid = AppData.payments
        .where((p) => p.period == _period && !p.isCancelled)
        .fold<double>(0, (sum, p) => sum + p.amount);

    return Scaffold(
      appBar: AppBar(title: const Text('المصروفات')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: DropdownButtonFormField<String>(
              value: _period,
              decoration: const InputDecoration(
                labelText: 'فترة التحصيل',
                border: OutlineInputBorder(),
              ),
              items: _periods.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
              onChanged: (value) => setState(() => _period = value ?? _period),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: _SummaryCard(label: 'المطلوب', value: totalRequired, icon: Icons.account_balance_wallet)),
                const SizedBox(width: 8),
                Expanded(child: _SummaryCard(label: 'المحصّل', value: totalPaid, icon: Icons.check_circle)),
                const SizedBox(width: 8),
                Expanded(child: _SummaryCard(label: 'المتبقي', value: totalRequired - totalPaid, icon: Icons.pending_actions)),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              itemCount: AppData.students.length,
              itemBuilder: (_, i) {
                final student = AppData.students[i];
                final paid = AppData.paidForStudent(student.id, _period);
                final remaining = (student.monthlyFee - paid).clamp(0, double.infinity);
                final complete = remaining == 0;

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(child: Text(student.name.characters.first)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(student.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                  Text(student.group, style: Theme.of(context).textTheme.bodySmall),
                                ],
                              ),
                            ),
                            Chip(
                              label: Text(complete ? 'مسدد' : 'متبقي ${remaining.toStringAsFixed(0)} ج.م'),
                              avatar: Icon(complete ? Icons.check : Icons.warning_amber, size: 18),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(value: student.monthlyFee == 0 ? 0 : (paid / student.monthlyFee).clamp(0, 1)),
                        const SizedBox(height: 6),
                        Text('المدفوع: ${paid.toStringAsFixed(0)} من ${student.monthlyFee.toStringAsFixed(0)} ج.م'),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _showHistory(student),
                                icon: const Icon(Icons.history),
                                label: const Text('سجل الدفعات'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: complete ? null : () => _showAddPayment(student),
                                icon: const Icon(Icons.add_card),
                                label: const Text('تسجيل دفعة'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.label, required this.value, required this.icon});

  final String label;
  final double value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 4),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 4),
            FittedBox(
              child: Text('${value.toStringAsFixed(0)} ج.م', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
