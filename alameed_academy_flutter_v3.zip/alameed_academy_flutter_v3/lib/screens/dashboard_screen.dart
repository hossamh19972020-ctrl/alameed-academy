import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../widgets/stat_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final unpaid = AppData.students.where((s) => !s.feesPaid).length;
    final absent = AppData.students.where((s) => s.isAbsent).length;
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('مرحبًا أ/ حسام حسن عبد الكريم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('العميد في اللغة العربية'),
          const SizedBox(height: 18),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 1.45,
            children: [
              StatCard(title: 'إجمالي الطلاب', value: '${AppData.students.length}', icon: Icons.people),
              StatCard(title: 'المجموعات', value: '${AppData.groups.length}', icon: Icons.groups),
              StatCard(title: 'الغائبون اليوم', value: '$absent', icon: Icons.person_off),
              StatCard(title: 'متأخرون في السداد', value: '$unpaid', icon: Icons.warning_amber),
            ],
          ),
          const SizedBox(height: 16),
          const Text('إجراءات سريعة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: const [
              ActionChip(label: Text('إضافة طالب'), avatar: Icon(Icons.person_add)),
              ActionChip(label: Text('تسجيل الحضور'), avatar: Icon(Icons.fact_check)),
              ActionChip(label: Text('إضافة اختبار'), avatar: Icon(Icons.quiz)),
              ActionChip(label: Text('إنشاء تقرير'), avatar: Icon(Icons.picture_as_pdf)),
            ],
          ),
        ],
      ),
    );
  }
}
