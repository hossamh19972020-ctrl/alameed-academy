class PaymentRecord {
  PaymentRecord({
    required this.id,
    required this.studentId,
    required this.amount,
    required this.period,
    required this.method,
    required this.recordedBy,
    required this.paidAt,
    this.notes = '',
    this.isCancelled = false,
    this.cancelReason,
    this.cancelledAt,
  });

  final String id;
  final int studentId;
  final double amount;
  final String period;
  final String method;
  final String recordedBy;
  final DateTime paidAt;
  final String notes;
  bool isCancelled;
  String? cancelReason;
  DateTime? cancelledAt;

  String get receiptNumber {
    final y = paidAt.year.toString().padLeft(4, '0');
    final m = paidAt.month.toString().padLeft(2, '0');
    final d = paidAt.day.toString().padLeft(2, '0');
    return 'PAY-$y$m$d-${id.padLeft(5, '0')}';
  }
}
