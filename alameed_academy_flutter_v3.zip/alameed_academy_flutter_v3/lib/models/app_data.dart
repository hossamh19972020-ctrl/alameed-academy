import 'payment_record.dart';
import 'student.dart';

class AppData {
  static final students = <Student>[
    Student(id: 1, name: 'أحمد محمد علي', phone: '01012345678', group: 'الأول الثانوي - مجموعة أ', grade: 85),
    Student(id: 2, name: 'محمد خالد إبراهيم', phone: '01087654321', group: 'الأول الثانوي - مجموعة أ', grade: 78),
    Student(id: 3, name: 'سارة حسن محمود', phone: '01123456789', group: 'الأول الثانوي - مجموعة ب', grade: 92),
    Student(id: 4, name: 'يوسف أحمد رمضان', phone: '01099887766', group: 'الثاني الثانوي - مجموعة أ', grade: 69),
    Student(id: 5, name: 'مريم علي فتحي', phone: '01234567890', group: 'الثالث الإعدادي - مجموعة أ', grade: 88),
  ];

  static final groups = <String>[
    'الأول الثانوي - مجموعة أ',
    'الأول الثانوي - مجموعة ب',
    'الثاني الثانوي - مجموعة أ',
    'الثالث الإعدادي - مجموعة أ',
  ];

  static final payments = <PaymentRecord>[
    PaymentRecord(
      id: '1',
      studentId: 1,
      amount: 500,
      period: 'يوليو 2026',
      method: 'نقدي',
      recordedBy: 'أ/ حسام حسن عبد الكريم',
      paidAt: DateTime(2026, 7, 20, 18, 30, 12),
    ),
  ];

  static double paidForStudent(int studentId, String period) {
    return payments
        .where((p) => p.studentId == studentId && p.period == period && !p.isCancelled)
        .fold(0, (sum, p) => sum + p.amount);
  }

  static List<PaymentRecord> paymentsForStudent(int studentId) {
    final result = payments.where((p) => p.studentId == studentId).toList();
    result.sort((a, b) => b.paidAt.compareTo(a.paidAt));
    return result;
  }

  static PaymentRecord addPayment({
    required int studentId,
    required double amount,
    required String period,
    required String method,
    required String notes,
  }) {
    final payment = PaymentRecord(
      id: (payments.length + 1).toString(),
      studentId: studentId,
      amount: amount,
      period: period,
      method: method,
      recordedBy: 'أ/ حسام حسن عبد الكريم',
      paidAt: DateTime.now(),
      notes: notes,
    );
    payments.add(payment);
    return payment;
  }
}
