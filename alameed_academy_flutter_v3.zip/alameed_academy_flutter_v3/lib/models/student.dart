class Student {
  Student({
    required this.id,
    required this.name,
    required this.phone,
    required this.group,
    this.isAbsent = false,
    this.monthlyFee = 500,
    this.grade = 0,
  });

  final int id;
  String name;
  String phone;
  String group;
  bool isAbsent;
  double monthlyFee;
  double grade;
}
